First, make sure you downloaded the complete webpage from caesar/student center and rename it to enrollment
Then, double click on easyCalendar.app you will get your calendar file
Enjoy!
Zip file has a sample html page
